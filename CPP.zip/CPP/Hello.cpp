#include <iostream>

int main()
{
    auto hello = [] () {std::cout << " \"HELLO, WORLD!\" " << std::endl;};
    return 0;
}
