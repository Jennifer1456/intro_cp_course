#include <iostream>

int main()
{
    int i = 1;
    while (i <= 8)
    {
        std::cout << ". . . . . . . . . . . . . . . . . . . . . . . ."
                  << "\n";
        std::cout << " . . . . . . . . . . . . . . . . . . . . . . ."
                  << "\n";
        i = i + 1;
    }
}